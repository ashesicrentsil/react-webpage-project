import React from 'react';
import './StudentRegistration.css';

const StudentRegistration = () => {
  const handleSubmit = () => {
    // Handle form submission
  };

  return (
    <div className="registration-container">
      <h2 className="registration-title">Student Registration</h2>
      <div className="form-container">
        <div className="form-field">
          <label htmlFor="firstName" className="form-label">Student Name:</label>
          <div className="name-inputs">
            <input type="text" id="firstName" className="name-input" placeholder="First Name" />
            <input type="text" id="lastName" className="name-input" placeholder="Last Name" />
          </div>
        </div>
        <div className="form-field">
          <label htmlFor="studentId" className="form-label">Student ID:</label>
          <input type="text" id="studentId" />
        </div>
        <div className="form-field">
          <label htmlFor="email" className="form-label">Email:</label>
          <input type="email" id="email" />
          <span className="subtext">example@st.ug.edu.gh</span>
        </div>
        <div className="form-field">
          <label htmlFor="programOffering" className="form-label">Program Offering:</label>
          <input type="text" id="programOffering" />
          <span className="subtext">BSc, BA, MA, PhD ....</span>
        </div>
        <div className="form-field">
          <label htmlFor="level" className="form-label">Level:</label>
          <input type="text" id="level" />
        </div>
        <button className="submit-button" onClick={handleSubmit}>
          Submit
        </button>
      </div>
    </div>
  );
};

export default StudentRegistration;
