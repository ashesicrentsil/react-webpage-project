import React from 'react';
import StudentRegistration from './StudentRegistration';

const App = () => {
  return (
    <div className="App">
      <StudentRegistration />
    </div>
  );
};

export default App;
