import React from 'react';
import StudentLogin from './StudentLogin';

function App() {
  return (
    <div className="App">
      <StudentLogin />
    </div>
  );
}

export default App;

