import React from 'react';
import './StudentLogin.css';

const StudentLogin = () => {
  return (
    <div className="login-container">
      <div className="form-container">
        <h2 className="login-title">Login</h2>
        <p>Sign Into Your Account</p>
        <div className="input-container">
          <label htmlFor="id">ID:</label>
          <input type="text" id="id" />
        </div>
        <div className="input-container">
          <label htmlFor="password">Password:</label>
          <input type="password" id="password" />
        </div>
        <button className="login-button">Login</button>
        <p className="forgot-password">I Forgot My Password. Click Here To Reset</p>
        <button className="signup-button">Sign Up</button>
      </div>
    </div>
  );
};

export default StudentLogin;
