import React from 'react';
import StudentInfoEntry from './StudentInfoEntry';

const App = () => {
  return (
    <div className="App">
      <StudentInfoEntry />
    </div>
  );
};

export default App;
