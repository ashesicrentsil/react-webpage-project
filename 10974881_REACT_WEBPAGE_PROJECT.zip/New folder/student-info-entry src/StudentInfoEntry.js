import React, { useState } from 'react';
import './StudentInfoEntry.css';

const StudentInfoEntry = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [birthdate, setBirthdate] = useState('');
  const [gender, setGender] = useState('');
  const [studentId, setStudentId] = useState('');
  const [level, setLevel] = useState('');
  const [program, setProgram] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission here
   
    setName('');
    setEmail('');
    setPhone('');
    setBirthdate('');
    setGender('');
    setStudentId('');
    setLevel('');
    setProgram('');
  };

  return (
    <div className="student-info-entry">
      <h2>Student Information Entry</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="name">Name:</label>
          <input type="text" id="name" value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div>
          <label htmlFor="email">Email:</label>
          <input type="email" id="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        <div>
          <label htmlFor="phone">Phone:</label>
          <input type="tel" id="phone" value={phone} onChange={(e) => setPhone(e.target.value)} />
        </div>
        <div>
          <label htmlFor="birthdate">Birthdate:</label>
          <input type="date" id="birthdate" value={birthdate} onChange={(e) => setBirthdate(e.target.value)} />
        </div>
        <div>
          <label htmlFor="gender">Gender:</label>
          <select id="gender" value={gender} onChange={(e) => setGender(e.target.value)}>
            <option value="">Select</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
          </select>
        </div>
        <div>
          <label htmlFor="studentId">Student ID:</label>
          <input type="text" id="studentId" value={studentId} onChange={(e) => setStudentId(e.target.value)} />
        </div>
        <div>
          <label htmlFor="level">Level:</label>
          <input type="text" id="level" value={level} onChange={(e) => setLevel(e.target.value)} />
        </div>
        <div>
          <label htmlFor="program">Program Offering:</label>
          <input type="text" id="program" value={program} onChange={(e) => setProgram(e.target.value)} />
        </div>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default StudentInfoEntry;
