import React from 'react';
import './Dashboard.css';

const Dashboard = () => {
  return (
    <div className="dashboard-container">
      <h1 className="welcome-heading">Welcome</h1>
      <div className="background-rectangle">
        <button>Make Payment</button>
        <button>Services</button>
        <button>Student Enquiry</button>
        <button>Profile</button>
      </div>
      <div className="additional-info">
        <h2>PROFILE</h2>
        <p>
          The University of Ghana, the premier university in Ghana, was founded as the University
          College of the Gold Coast by Ordinance on August 11, 1948, for the purpose of providing
          and promoting university education, learning, and research.
        </p>
        <h3>OUR VISION</h3>
        <p>To become a world-class research-intensive university.</p>
        <h3>OUR MISSION</h3>
        <p>
          We will create an enabling environment that makes the University of Ghana increasingly
          relevant to national and global development.
        </p>
      </div>
    </div>
  );
};

export default Dashboard;
